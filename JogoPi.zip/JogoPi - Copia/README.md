# JogoPi
Este repositorio foi feito para mostrar codigos feitos em linguagens diferente sobre o jogo do PI
Vamos lá pro teste:

Recebendo de input qualquer número natural, o sistema deve mostrar na tela uma contagem de 1 em 1 (1,2,3,4..) seguindo as regras do jogo do Pi.

Regras do jogo do Pi:
* Todos números múltiplos de 7 devem ser substituídos pela string "Pi"
* Todos números terminados em 7 devem ser substituídos pela string "Pi"

O teste pode ser realizado em qualquer linguagem e entregue de qualquer maneira, porém é preferível que seja entregue por um repositório no GitHub e seja programado usando NodeJS (preferencialmente com TypeScript)
