import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado=new Scanner(System.in);
		
		int Num1=0 , Num2=1 ,PI=7  ;
		
		System.out.println("Digite o valor :");
		Num1 = teclado.nextInt();
		
		System.out.println("Digite o valor a ser trocado pela palavra PI :");
		PI = teclado.nextInt();
		
		while(Num2<=Num1){
			if(Num2%PI == 0) {
				System.out.println("PI,");
			}else
			if((Num2-PI)%10 == 0) {
				System.out.println("PI,");
			}
			else {
				System.out.println(Num2+",");
			}
			
			Num2=Num2+1;
			
		};
		
		
		teclado.close();
	}

}
